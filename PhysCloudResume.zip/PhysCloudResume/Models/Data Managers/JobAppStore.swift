import SwiftData

@Observable final class JobAppStore {
  var jobApps: [JobApp] = []
  var selectedApp: JobApp?
  var form = JobAppForm()
  var resStore: ResStore?

  private var modelContext: ModelContext?
  init() {

  }
  func initialize(context: ModelContext, resStore: ResStore) {
    modelContext = context
    self.resStore = resStore
    loadJobApps()  // Load data from the database when the store is initialized
  }

  // Load JobApps from the database

  private func loadJobApps() {
    let descriptor = FetchDescriptor<JobApp>()
    do {
      jobApps = try modelContext!.fetch(descriptor)
    } catch {
      print("Failed to fetch JobApps: \(error)")
    }
  }
  // Methods to manage jobApps
  func updateJobAppStatus(_ jobApp: JobApp, to newStatus: Statuses) {
    jobApp.status = newStatus
//    saveContext()
    // Handle additional logic like saving or notifying listeners
  }
  func addJobApp(_ jobApp: JobApp) -> JobApp? {
    jobApps.append(jobApp)
    modelContext!.insert(jobApp)
//    saveContext()
    return jobApps.last
  }
  func deleteSelected() {
    guard let deleteMe = selectedApp else {
      fatalError("No job application available to delete.")
    }

    self.deleteJobApp(deleteMe)
    selectedApp = self.jobApps.last  //!FixMe Problematic?
  }
  func deleteJobApp(_ jobApp: JobApp) {

    if let index = jobApps.firstIndex(of: jobApp) {
      if let resStore = resStore {
        jobApp.resumes.forEach { resume in
          resStore.deleteRes(resume)
        }
        jobApps.remove(at: index)
        modelContext!.delete(jobApp)
//        saveContext()  //Error thrown here}
        if self.selectedApp == jobApp {
          self.selectedApp = nil
        }
        if self.selectedApp == nil {
          self.selectedApp = self.jobApps.first
        }
      } else {
        print("ResStore ref not here!")
      }
    }

  }
  private func populateFormFromObj(_ jobApp: JobApp) {
    form.populateFormFromObj(jobApp)
  }

  func editWithForm(_ jobApp: JobApp? = nil) {
    let jobAppEditing = jobApp ?? selectedApp
    guard let jobAppEditing = jobAppEditing else {
      fatalError("No job application available to edit.")
    }
    self.populateFormFromObj(jobAppEditing)
  }
  func cancelFormEdit(_ jobApp: JobApp? = nil) {
    let jobAppEditing = jobApp ?? selectedApp
    guard let jobAppEditing = jobAppEditing else {
      fatalError("No job application available to restore state.")
    }
    self.populateFormFromObj(jobAppEditing)
  }

  func saveForm(_ jobApp: JobApp? = nil) {
    let jobAppToSave = jobApp ?? selectedApp
    guard let jobAppToSave = jobAppToSave else {
      fatalError("No job application available to save.")
    }
    jobAppToSave.assignPropsFromForm(form)
//    saveContext()

  }

  // Save changes to the database
  private func saveContext() {
    print("don't call this manually!")
    do {
      try modelContext!.save()
      print("saved")
    } catch {
      print("Failed to save context: \(error)")
    }
  }
}
