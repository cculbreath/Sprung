import SwiftUI

@ToolbarContentBuilder
func CoverLetterToolbar(
  buttons: Binding<CoverLetterButtons>,
  refresh: Binding<Bool>

) -> some ToolbarContent {
  ToolbarItem(placement: .automatic) {
    CoverLetterAiView(
      buttons: buttons,
      refresh: refresh
    ).onAppear{print("foo")}

  }
  ToolbarItem(placement: .automatic) {
    Button(action: {
      buttons.wrappedValue.showInspector.toggle()
    }) {
      Label("Toggle Inspector", systemImage: "sidebar.right")
    }.onAppear{print("Toolbar Cover Letter")}
  }
}
