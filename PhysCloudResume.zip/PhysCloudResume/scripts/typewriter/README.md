Theme: Basis
============
A basis résumé theme for HackMyResume, FluentCV, and other FRESH-compatible
resume tools.

## Use

The basis theme contains default theme files for use in other themes. Other
FRESH themes can inherit from the basis theme (or any theme) in order to provide
default formats that the theme author(s) may not necessarily be interested in.

## License

MIT. See [LICENSE.md][lic] for details.

[lic]: https://github.com/fluentdesk/fresh-themes/blob/master/LICENSE.md
