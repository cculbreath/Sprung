//
//  StackSecondView.swift
//  PhysCloudResume
//
//  Created by Christopher Culbreath on 9/2/24.
//

import SwiftUI

struct StackSecondView: View {
  var body: some View {
    Text( /*@START_MENU_TOKEN@*/"Hello, World!" /*@END_MENU_TOKEN@*/)
  }
}
